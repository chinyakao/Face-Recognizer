You can directly rename this folder to `data`
Then, put the OpenCV data inside.

OpenCV Github：https://github.com/opencv/opencv/tree/4.x/data
Frontal Face Model：haarcascade_frontalface_default.xml


```
data
├── catmeme.png
├── CMakeLists.txt
├── face.yml
├── haarcascade_frontalface_default.xml
├── haarcascades
├── haarcascades_cuda
├── hogcascades
├── lbpcascades
├── mona.png
├── pic
├── readme.txt
└── vec_files
```